char *escape_string(const char *str, char *buffer, int buffer_size);
char *escape_texi_string(const char *str, char *buffer, int buffer_size);
